// Re-export entry for DSH plugin bundler convenience.
// Some DSH builds bundle <pkg>/client.js directly.
export * from './lib/client.js'
